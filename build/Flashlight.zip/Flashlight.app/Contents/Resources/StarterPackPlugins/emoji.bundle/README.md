# Emoji Plugin for [Flashlight](http://flashlight.nateparrott.com/)
To search for emojis, use `emoji {{name}}` or `:{{name}}:`

![ScreenShot](Screenshot.png)

